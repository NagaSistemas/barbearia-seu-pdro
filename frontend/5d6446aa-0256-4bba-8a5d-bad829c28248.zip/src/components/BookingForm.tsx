import React, { useEffect, useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { CalendarIcon, ClockIcon, CheckIcon } from 'lucide-react';
export function BookingForm() {
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [availableTimes, setAvailableTimes] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: '',
    barber: '',
    message: ''
  });
  // Generate available time slots based on selected date
  useEffect(() => {
    if (selectedDate) {
      // In a real app, this would come from an API based on barber availability
      const times = [];
      const day = selectedDate.getDay();
      // Different hours for weekdays vs weekend
      const startHour = day === 0 ? null : day === 6 ? 9 : 9; // Sunday closed, Saturday and weekdays from 9
      const endHour = day === 0 ? null : day === 6 ? 18 : 20; // Sunday closed, Saturday until 6pm, weekdays until 8pm
      // Generate time slots in 30-minute increments
      if (startHour !== null) {
        for (let hour = startHour; hour < endHour; hour++) {
          times.push(`${hour}:00`);
          times.push(`${hour}:30`);
        }
      }
      // Randomly mark some slots as unavailable (for demo purposes)
      const available = times.filter(() => Math.random() > 0.3);
      setAvailableTimes(available);
      setSelectedTime(null);
    } else {
      setAvailableTimes([]);
      setSelectedTime(null);
    }
  }, [selectedDate]);
  const handleChange = e => {
    const {
      name,
      value
    } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  const handleSubmit = e => {
    e.preventDefault();
    if (!selectedTime) {
      alert('Por favor, selecione um horário disponível.');
      return;
    }
    // Combine date and time for the full appointment datetime
    const appointmentDateTime = new Date(selectedDate);
    const [hours, minutes] = selectedTime.split(':').map(Number);
    appointmentDateTime.setHours(hours, minutes);
    // Here you would handle the form submission, e.g., send to a server
    alert(`Agendamento recebido para ${appointmentDateTime.toLocaleString('pt-BR')}! Entraremos em contato para confirmar.`);
    // Reset form
    setFormData({
      name: '',
      phone: '',
      email: '',
      service: '',
      barber: '',
      message: ''
    });
    setSelectedDate(null);
    setSelectedTime(null);
  };
  // Custom styles for highlighting today's date and selected date
  const highlightWithRanges = [{
    'react-datepicker__day--highlighted-custom-1': [new Date()]
  }];
  // Function to check if a date should be disabled (e.g. past dates or Sundays)
  const isDateDisabled = date => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    // Disable past dates and Sundays
    return date < today || date.getDay() === 0;
  };
  return <section id="booking" className="py-16 bg-black text-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-2">
          Agende Seu Horário
        </h2>
        <p className="text-center text-gray-400 mb-12">
          Preencha o formulário abaixo e reserve seu horário com nossos
          profissionais.
        </p>
        <div className="max-w-5xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left column - Customer details */}
              <div className="space-y-6">
                <h3 className="text-xl font-semibold flex items-center">
                  <span className="bg-amber-600 text-white rounded-full w-8 h-8 inline-flex items-center justify-center mr-3">
                    1
                  </span>
                  Seus Dados
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block mb-2 text-sm font-medium">
                      Nome Completo
                    </label>
                    <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className="bg-gray-800 border border-gray-700 text-white rounded-md w-full p-2.5" placeholder="Seu nome" required />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block mb-2 text-sm font-medium">
                      Telefone
                    </label>
                    <input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange} className="bg-gray-800 border border-gray-700 text-white rounded-md w-full p-2.5" placeholder="(00) 00000-0000" required />
                  </div>
                </div>
                <div>
                  <label htmlFor="email" className="block mb-2 text-sm font-medium">
                    Email
                  </label>
                  <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} className="bg-gray-800 border border-gray-700 text-white rounded-md w-full p-2.5" placeholder="seuemail@example.com" required />
                </div>
                <h3 className="text-xl font-semibold flex items-center pt-4">
                  <span className="bg-amber-600 text-white rounded-full w-8 h-8 inline-flex items-center justify-center mr-3">
                    2
                  </span>
                  Escolha o Serviço
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="service" className="block mb-2 text-sm font-medium">
                      Serviço
                    </label>
                    <select id="service" name="service" value={formData.service} onChange={handleChange} className="bg-gray-800 border border-gray-700 text-white rounded-md w-full p-2.5" required>
                      <option value="">Selecione um serviço</option>
                      <option value="corte">Corte de Cabelo</option>
                      <option value="barba">Barba Completa</option>
                      <option value="corte-barba">Corte + Barba</option>
                      <option value="tratamento">Tratamentos Capilares</option>
                      <option value="pigmentacao">Pigmentação Capilar</option>
                      <option value="premium">Pacote Premium</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="barber" className="block mb-2 text-sm font-medium">
                      Barbeiro
                    </label>
                    <select id="barber" name="barber" value={formData.barber} onChange={handleChange} className="bg-gray-800 border border-gray-700 text-white rounded-md w-full p-2.5" required>
                      <option value="">Selecione um barbeiro</option>
                      <option value="carlos">Carlos Mendes</option>
                      <option value="ricardo">Ricardo Oliveira</option>
                      <option value="marcos">Marcos Silva</option>
                      <option value="rafael">Rafael Costa</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label htmlFor="message" className="block mb-2 text-sm font-medium">
                    Mensagem (opcional)
                  </label>
                  <textarea id="message" name="message" value={formData.message} onChange={handleChange} rows={3} className="bg-gray-800 border border-gray-700 text-white rounded-md w-full p-2.5" placeholder="Alguma observação ou preferência especial..."></textarea>
                </div>
              </div>
              {/* Right column - Calendar and time selection */}
              <div className="bg-gray-900 p-6 rounded-lg">
                <h3 className="text-xl font-semibold flex items-center mb-6">
                  <span className="bg-amber-600 text-white rounded-full w-8 h-8 inline-flex items-center justify-center mr-3">
                    3
                  </span>
                  Escolha a Data e Horário
                </h3>
                <div className="mb-6">
                  <label className="block mb-2 text-sm font-medium flex items-center">
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    Selecione uma data
                  </label>
                  <div className="calendar-container">
                    <DatePicker selected={selectedDate} onChange={date => setSelectedDate(date)} filterDate={date => !isDateDisabled(date)} highlightDates={highlightWithRanges} inline calendarClassName="bg-gray-800 border border-gray-700 rounded-lg p-4 mx-auto" dayClassName={date => date.getDate() === new Date().getDate() && date.getMonth() === new Date().getMonth() && date.getFullYear() === new Date().getFullYear() ? 'bg-amber-600 text-white rounded-full' : undefined} />
                  </div>
                </div>
                {selectedDate && <div>
                    <label className="block mb-3 text-sm font-medium flex items-center">
                      <ClockIcon className="w-4 h-4 mr-2" />
                      Horários disponíveis para{' '}
                      {selectedDate.toLocaleDateString('pt-BR')}:
                    </label>
                    {availableTimes.length > 0 ? <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                        {availableTimes.map(time => <button key={time} type="button" className={`p-2 rounded-md text-center text-sm transition-colors ${selectedTime === time ? 'bg-amber-600 text-white' : 'bg-gray-800 hover:bg-gray-700'}`} onClick={() => setSelectedTime(time)}>
                            {time}
                            {selectedTime === time && <CheckIcon className="w-4 h-4 inline-block ml-1" />}
                          </button>)}
                      </div> : <p className="text-amber-500">
                        Não há horários disponíveis nesta data. Por favor,
                        selecione outra data.
                      </p>}
                  </div>}
                {!selectedDate && <div className="text-center text-gray-400 mt-6">
                    <p>Selecione uma data para ver os horários disponíveis</p>
                  </div>}
              </div>
            </div>
            <div className="flex justify-center pt-6">
              <button type="submit" disabled={!selectedDate || !selectedTime} className={`font-medium rounded-md px-8 py-3 transition-colors ${selectedDate && selectedTime ? 'bg-amber-600 hover:bg-amber-700 text-white' : 'bg-gray-700 text-gray-400 cursor-not-allowed'}`}>
                {selectedDate && selectedTime ? `Agendar para ${selectedDate.toLocaleDateString('pt-BR')} às ${selectedTime}` : 'Selecione data e horário'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>;
}